import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-selected-image',
  templateUrl: './selected-image.component.html',
  styleUrls: ['./selected-image.component.css']
})
export class SelectedImageComponent implements OnInit {
  newObservationX = 0;
  newObservationY = 0;
  newObservationVisible = false;

  //  element: HTMLElement = document.getElementById('myDiv');
  @ViewChild('imageWrapper') element: ElementRef | undefined

  constructor() { }

  ngOnInit(): void {
  }

  clicked(event: MouseEvent): void {
    if (this.element) {
      this.element.nativeElement.setAttribute("style", "position: absolute;top: " + event.pageY+"px;left:"+event.pageX +"px;width: 10px;height:10px;background: #000000");
    }


    //   if($('div').length < 3) {
    //     $("body").append(            
    //         $('<div class="point"></div>').css({
    //             position: 'absolute',
    //             top: event.pageY + 'px',
    //             left: event.pageX + 'px',
    //             width: '10px',
    //             height: '10px',
    //             background: '#000000'
    //         })              
    //     );
    // }

    this.newObservationX = event.pageX;
    this.newObservationY = event.pageY;
    this.newObservationVisible = true;
  }

  addPoint(x: number, y: number): void {

  }
}
