import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-observation-detail',
  templateUrl: './observation-detail.component.html',
  styleUrls: ['./observation-detail.component.css']
})
export class ObservationDetailComponent implements OnInit {
  @Input() x = 0;
  @Input() y = 0;
  @Input() visible = false;
  name = "";

  constructor() { }

  ngOnInit(): void {
  }

}
